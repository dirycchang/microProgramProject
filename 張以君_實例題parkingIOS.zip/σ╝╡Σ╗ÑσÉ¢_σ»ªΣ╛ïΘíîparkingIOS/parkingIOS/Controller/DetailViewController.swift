//
//  DetailViewController.swift
//  parkingIOS
//
//  Created by Yi Chun on 2018/11/1.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class DetailViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var myMapKit: MKMapView!
    

    @IBOutlet weak var tableView: UITableView!
    var name:String = ""
    var area:String = ""
    var time:String = ""
    var address:String = ""
    var tw97x:String = ""
    var tw97y:String = ""
    
    var itemArray = [String]()
    var titleArrey = ["停車場名稱","區域","營業時間","地址"]
    
    var getWGS = ValueOf_WGS84()
    var myWPS = [Double]()
    var myLocationManager: CLLocationManager = CLLocationManager() //GPS管理員
    
    private var parkingArray = [parkingStruct]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    
    var detailViewController:DetailViewController?
    private let cellName = "cellName"
    private let cellArea = "cellArea"
    private let cellTime = "cellTime"
    private let cellAddress = "cellAddress"
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }
    

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! detail_TableViewCell
        cell.nameLabel.text = itemArray[indexPath.row]
        cell.titleLabel.text = titleArrey[indexPath.row]
        cell.nameLabel?.textColor = .white
        cell.titleLabel?.textColor = .white
        cell.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let ann = MKPointAnnotation()
        myWPS = getWGS.getValueOf_WGS84(posX: tw97x, posY: tw97y)
        print("===測試===",myWPS)
        ann.coordinate = CLLocationCoordinate2D(latitude: myWPS[1], longitude: myWPS[0])
        ann.title = "停車場在這裡！"
        
        let userLocation: MKUserLocation = myMapKit.userLocation
        let region: MKCoordinateRegion = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 1000.0, 1000.0)
        myMapKit.setRegion(region, animated: true)
        myMapKit.addAnnotation(ann)
        myMapKit.setCenter(ann.coordinate, animated: false)
        
        let rightBarButton = UIBarButtonItem(title: "導航", style: UIBarButtonItemStyle.plain, target: self, action: #selector(self.myRightSideBarButtonItemTapped(_:)))
        self.navigationItem.rightBarButtonItem = rightBarButton
        tableView.backgroundColor =  #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        
    }

    @objc func myRightSideBarButtonItemTapped(_ sender:UIBarButtonItem!)
    {
        
        let userLocation: MKUserLocation = myMapKit.userLocation
        //導航
        let myLocation = CLLocationCoordinate2D(latitude: userLocation.coordinate.latitude, longitude: userLocation.coordinate.longitude)
        let destination = CLLocationCoordinate2D(latitude: myWPS[1], longitude: myWPS[0])
        let pA = MKPlacemark(coordinate: myLocation, addressDictionary: nil)
        let pB = MKPlacemark(coordinate: destination, addressDictionary: nil)
        
        let miA = MKMapItem(placemark: pA)
        let miB = MKMapItem(placemark: pB)
        
        miA.name = "現在位置"
        miB.name = "目的地"
        
        let routes = [miA,miB]
        let options = [MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving]
        
        MKMapItem.openMaps(with: routes, launchOptions: options)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
