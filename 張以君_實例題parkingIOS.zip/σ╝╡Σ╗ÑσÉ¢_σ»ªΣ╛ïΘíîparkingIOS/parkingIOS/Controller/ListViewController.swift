//
//  ViewController.swift
//  parkingIOS
//
//  Created by Yi Chun on 2018/10/31.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class ListViewController: UIViewController,UITableViewDataSource, UITableViewDelegate, UISearchResultsUpdating {
    
    @IBOutlet weak var tableView: UITableView!
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    private let cellID = "cellID"
    private var parkingArray = [parkingStruct]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    
    //下拉更新控制器
    var searchAdv = [parkingStruct]()
    
    var refreshController = UIRefreshControl()
    
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchString = searchController.searchBar.text!
        
        searchAdv = parkingArray.filter { (name) -> Bool in
            return name.NAME.contains(searchString) || name.AREA.contains(searchString)
        }
        tableView.reloadData()
    }
    
    
    let service = Service_parking()
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if #available(iOS 11.0, *) {
            if navigationItem.searchController?.isActive == true {
                return searchAdv.count
                //return moviesArray.count
            } else {
                return parkingArray.count
            }
        } else {
            // Fallback on earlier versions
            return parkingArray.count
        }
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID) as! Cell_parking
        
        if #available(iOS 11.0, *) {
            if navigationItem.searchController?.isActive == true {
                //cell.textLabel?.text = searchSongs[indexPath.row]
                let search = searchAdv[indexPath.row]
                let parkingViewModel = ViewModel_parking(model: search)
                cell.displayParkingInCell(using: parkingViewModel)
                
                
            } else {
                let parkingLots = parkingArray[indexPath.row]
                let parkingViewModel = ViewModel_parking(model: parkingLots)
                cell.displayParkingInCell(using: parkingViewModel)
            }
        } else {
            let parkingLots = parkingArray[indexPath.row]
            let parkingViewModel = ViewModel_parking(model: parkingLots)
            cell.displayParkingInCell(using: parkingViewModel)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let myVCDetail: DetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "vc詳細資訊") as! DetailViewController
        
        if navigationItem.searchController?.isActive == true {
            
            myVCDetail.itemArray.append(searchAdv[indexPath.row].NAME)
            myVCDetail.itemArray.append(searchAdv[indexPath.row].AREA)
            myVCDetail.itemArray.append(searchAdv[indexPath.row].SERVICETIME)
            myVCDetail.itemArray.append(searchAdv[indexPath.row].ADDRESS)
            myVCDetail.tw97x = searchAdv[indexPath.row].TW97X
            myVCDetail.tw97y = searchAdv[indexPath.row].TW97Y
           
            self.navigationController?.show(myVCDetail, sender: nil)
            
        } else {
            myVCDetail.itemArray.append(parkingArray[indexPath.row].NAME)
            myVCDetail.itemArray.append(parkingArray[indexPath.row].AREA)
            myVCDetail.itemArray.append(parkingArray[indexPath.row].SERVICETIME)
            myVCDetail.itemArray.append(parkingArray[indexPath.row].ADDRESS)
            myVCDetail.tw97x = parkingArray[indexPath.row].TW97X
            myVCDetail.tw97y = parkingArray[indexPath.row].TW97Y
           
            self.navigationController?.show(myVCDetail, sender: nil)
        }

    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        tableView.register(Cell_parking.self, forCellReuseIdentifier: cellID)
        tableView.contentInset = UIEdgeInsets(top: 22, left: 0, bottom: 0, right: 0)
        getParking(fromService: service)
        
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self as UISearchResultsUpdating
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.tintColor = UIColor.green
        searchController.searchBar.barTintColor = UIColor.red
        searchController.searchBar.searchBarStyle = .minimal
        
        //searchController.searchBar.backgroundColor = UIColor.white
        
        if #available(iOS 11.0, *) {
            navigationItem.searchController = searchController
        } else {
            // Fallback on earlier versions
        }
        definesPresentationContext = true
        
        //下拉更新
        refreshController.addTarget(self, action: #selector(ListViewController.refreshData), for: .valueChanged)
        refreshController.attributedTitle = NSAttributedString(string: "下拉更新數據")
        tableView.addSubview(refreshController)
        refreshData()
   
    }
    
    //更新數據
    @objc func refreshData() {
        
        //移除數據
        self.parkingArray.removeAll()
        self.tableView.reloadData()
        self.refreshController.endRefreshing()
    }
    
    private func getParking<S: Gettable_parking>(fromService service: S) where S.T == Array<parkingStruct?> {
        
        service.get { [weak self] (result) in
            switch result {
            case .Success(let parkingLots):
                var tempLots = [parkingStruct]()
                for parkinglot in parkingLots {
                    if let parkinglot = parkinglot {
                        tempLots.append(parkinglot)
                    }
                }
                self?.parkingArray = tempLots
            //dump(self.movies)
            case .Error(let error):
                print(error)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

