//
//  APIFactory.swift
//  parkingIOS
//
//  Created by Yi Chun on 2018/10/31.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

class APIFactory: NSObject{
    
    let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate //隱含轉換成AppDelegate
    var strData: Data?
    
    
    //GET全部
    func getAll(url: String) -> Data{
        
        //建立方法回傳的字串 //此方法會將非ASCII的字元轉為ASCII
        let strPerEScURL:String = url.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        ////////以下為標準流程///////(沒特別含意)
        let myURL:URL = URL(string: strPerEScURL)!
        let mySessionConfig:URLSessionConfiguration = URLSessionConfiguration.default
        let mySession:URLSession = URLSession(configuration: mySessionConfig, delegate: nil, delegateQueue: nil)
        
        //向瀏覽器請求 使用GET方法
        var myRequest = URLRequest(url:myURL)
        myRequest.httpMethod = "GET"
        
        let myDataTask = mySession.dataTask(with: myRequest, completionHandler: {
            (data:Data?, response:URLResponse?, error:Error?) -> Void in
            
            if error == nil{
                self.strData = data
                
            }else{
                print("錯誤:\(String(describing: error?.localizedDescription))")
                //return strData
            }
        })
        myDataTask.resume()
        
        sleep(1)
        return strData!
        
    }
    
    //解析JSON:地區
    func parseArea(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["records"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["AREA"] as! String
                
                resultArray.append(nameResult)
                
                
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析JSON:名稱
    func parseName(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["records"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["NAME"] as! String
                
                resultArray.append(nameResult)
                
                
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析JSON:地址
    func parseAddress(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["records"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["ADDRESS"] as! String
                
                resultArray.append(nameResult)
                
                
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析JSON:開放時間
    func parseServiceTime(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["records"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["SERVICETIME"] as! String
                
                resultArray.append(nameResult)
                
                
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
}
