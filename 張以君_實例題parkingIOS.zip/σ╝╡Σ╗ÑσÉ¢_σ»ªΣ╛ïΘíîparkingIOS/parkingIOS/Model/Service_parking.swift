//
//  Service_parking.swift
//  parkingIOS
//
//  Created by Yi Chun on 2018/10/31.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

//2 conform to protocol
struct Service_parking: Gettable_parking {
    
    //    let QSPhotoType:String
    //    let QSLocation :String
    //    init(QSPhotoType PhotoType:String, QSLocation Location:String){
    //        self.QSPhotoType = PhotoType
    //        self.QSLocation = Location
    //    }
    
    
    //3
    let endpoint: String = "http://data.ntpc.gov.tw/api/v1/rest/datastore/382000000A-000225-002"
    
    let downloader = JSONDownloader()
    
    //the associated type is inferred by <[Movie?]>
    typealias CurrentWeatherCompletionHandler = (Result<[parkingStruct?]>) -> ()
    
    //4 protocol required function
    func get(completion: @escaping CurrentWeatherCompletionHandler) {
        
        guard let url = URL(string: self.endpoint) else {
            completion(.Error(.invalidURL))
            return
        }
        //5 using the JSONDownloader function
        let request = URLRequest(url: url)
        let task = downloader.jsonTask(with: request) { (result) in
            
            DispatchQueue.main.async {
                switch result {
                case .Error(let error):
                    completion(.Error(error))
                    return
                case .Success(let json):
                    //6 parsing the Json response
                    guard let resultDict = json["result"] as? [String: AnyObject], let recordArray = resultDict["records"] as? [[String: AnyObject]] else {
                        completion(.Error(.jsonParsingFailure))
                        return
                    }
                    //7 maping the array and create Movie objects
                    let dataArray = recordArray.map{parkingStruct(json: $0)}
                    completion(.Success(dataArray))
                }
            }
        }
        task.resume()
    }
}

//1 uisng associatedType in protocol
protocol Gettable_parking {
    
    associatedtype T
    func get(completion: @escaping (Result<T>) -> Void)  //T：代表全部
}
