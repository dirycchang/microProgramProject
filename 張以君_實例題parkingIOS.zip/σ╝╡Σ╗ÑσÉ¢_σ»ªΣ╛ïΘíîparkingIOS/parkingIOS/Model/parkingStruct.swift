//
//  parkingStruct.swift
//  parkingIOS
//
//  Created by Yi Chun on 2018/10/31.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

struct parkingStruct {
    
    
    let ID: String
    let AREA: String
    let NAME: String
    let TYPE: String
    let SUMMARY: String
    let ADDRESS: String
    let TEL: String
    let PAYEX: String
    let SERVICETIME: String
    let TW97X:String
    let TW97Y:String
    
}

extension parkingStruct {
    
    struct Key  {
        
        
        static let ID = "ID"
        static let AREA = "AREA"
        static let NAME = "NAME"
        static let TYPE = "TYPE"
        static let SUMMARY = "SUMMARY"
        static let ADDRESS = "ADDRESS"
        static let TEL = "TEL"
        static let PAYEX = "PAYEX"
        static let SERVICETIME = "SERVICETIME"
        static let TW97X = "TW97X"
        static let W97Y = "TW97Y"
        
    }
    
    //failable initializer
    init?(json: [String: AnyObject]) {
        
        
        guard
            let ID = json[Key.ID] as? String,
            let AREA = json[Key.AREA] as? String,
            let NAME = json[Key.NAME] as? String,
            let TYPE = json[Key.TYPE] as? String,
            let SUMMARY = json[Key.SUMMARY] as? String,
            let ADDRESS = json[Key.ADDRESS] as? String,
            let TEL = json[Key.TEL] as? String,
            let PAYEX = json[Key.PAYEX] as? String,
            let SERVICETIME = json[Key.SERVICETIME] as? String,
            let TW97X = json[Key.TW97X] as? String,
            let TW97Y = json[Key.W97Y] as? String
            else {
                return nil
        }
        
        //self.data = Data(Data: data)
        self.ID = ID
        self.AREA = AREA
        self.NAME = NAME
        self.TYPE = TYPE
        self.SUMMARY = SUMMARY
        self.ADDRESS = ADDRESS
        self.TEL = TEL
        self.PAYEX = PAYEX
        self.SERVICETIME = SERVICETIME
        self.TW97X = TW97X
        self.TW97Y = TW97Y
        
    }
    
}
