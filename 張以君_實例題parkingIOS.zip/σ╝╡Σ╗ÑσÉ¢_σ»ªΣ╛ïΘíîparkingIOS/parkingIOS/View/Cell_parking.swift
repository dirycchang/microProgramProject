//
//  Cell_parking.swift
//  parkingIOS
//
//  Created by Yi Chun on 2018/10/31.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

class Cell_parking: UITableViewCell {
    
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    

    
    let nameLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    let addressLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    let locationLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    let timeLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .right
        l.textColor = .white
        return l
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpViews() {
        backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        
        addSubview(timeLabel)
        timeLabel.widthAnchor.constraint(equalToConstant: 250).isActive = true
        timeLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        timeLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: -10).isActive = true
        timeLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        
        addSubview(nameLabel)
        nameLabel.widthAnchor.constraint(equalToConstant: 250).isActive = true
        nameLabel.heightAnchor.constraint(equalToConstant: 80).isActive = true
        nameLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        nameLabel.leftAnchor.constraint(equalTo: leftAnchor, constant: 10).isActive = true
        
//        addSubview(addressLabel)
//        addressLabel.widthAnchor.constraint(equalToConstant: 1500).isActive = true
        
        
        addSubview(locationLabel)
        locationLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        locationLabel.leftAnchor.constraint(equalTo: nameLabel.leftAnchor).isActive = true
        locationLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: -10).isActive = true
        locationLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor).isActive = true
        
    }
    
    func displayParkingInCell(using viewModel: ViewModel_parking) {
        
        nameLabel.text = viewModel.NAME
        locationLabel.text = viewModel.AREA
        timeLabel.text = viewModel.SERVICETIME
        
        
        
    }
}
