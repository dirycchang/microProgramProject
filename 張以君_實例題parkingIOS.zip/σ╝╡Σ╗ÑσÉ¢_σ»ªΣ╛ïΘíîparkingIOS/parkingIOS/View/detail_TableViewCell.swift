//
//  detail_TableViewCell.swift
//  parkingIOS
//
//  Created by Yi Chun on 2018/11/1.
//  Copyright © 2018年 YiChun. All rights reserved.
//
import UIKit

class detail_TableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    
}
