//
//  ViewModel_parking.swift
//  parkingIOS
//
//  Created by Yi Chun on 2018/10/31.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

struct ViewModel_parking {
    
    let ID: String
    let AREA: String
    let NAME: String
    let TYPE: String
    let SUMMARY: String
    let ADDRESS: String
    let TEL: String
    let PAYEX: String
    let SERVICETIME: String
    let TW97X:String
    let TW97Y:String
    
    
    init(model: parkingStruct) {
        self.ID = model.ID
        //self.title = model.title.uppercased()
        self.AREA = model.AREA
        self.NAME = model.NAME
        self.TYPE = model.TYPE
        self.SUMMARY = model.SUMMARY
        self.ADDRESS = model.ADDRESS
        self.TEL = model.TEL
        self.PAYEX = model.PAYEX
        self.SERVICETIME = model.SERVICETIME
        self.TW97X = model.TW97X
        self.TW97Y = model.TW97Y
    }
}
